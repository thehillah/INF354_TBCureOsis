import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsersComponent } from './users/users.component';
import { MedecineComponent } from './medecine/medecine.component';
import { HomeComponent } from './home/home.component';
import { SymptomsComponent } from './symptoms/symptoms.component';
import { PatientTComponent } from './patient-t/patient-t.component';   
import { DashboardComponent } from './dashboard/dashboard.component';    
import { LoginComponent } from './login/login.component';    
import { RegisterComponent } from './register/register.component';
import { AppComponent } from './app.component';


const routes: Routes = [

{path: "users",component: UsersComponent},

{path: "medicines", component: MedecineComponent},
{path: "home",component: HomeComponent},
{path: "symptoms",component: SymptomsComponent},
{path: "patients", component: PatientTComponent},
{path: "register_",component:RegisterComponent},
{path: "login_",component:LoginComponent},
{path: "Dashboard_", component:DashboardComponent},
{path: "AdminPage",component: AppComponent},



{    
  path: '',    
  redirectTo: 'login',    
  pathMatch: 'full',    
},    
{    
  path: 'login',    
  component: LoginComponent,    
  data: {    
    title: 'Login Page'    
  }    
},    
{    
  path: 'Dasboard',    
  component: DashboardComponent,     
  data: {    
    title: 'Dashboard Page'    
  }    
},    
{    
  path: 'AddUser',    
  component: RegisterComponent,    
  data: {    
    title: 'Add User Page'    
  }    
}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponets = [MedecineComponent,UsersComponent,HomeComponent,SymptomsComponent,PatientTComponent,RegisterComponent,LoginComponent,DashboardComponent,AppComponent]
