import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AsymptomsComponent } from './asymptoms.component';

describe('AsymptomsComponent', () => {
  let component: AsymptomsComponent;
  let fixture: ComponentFixture<AsymptomsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AsymptomsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AsymptomsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
