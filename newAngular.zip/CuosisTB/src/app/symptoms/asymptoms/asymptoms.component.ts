import { Component, OnInit } from '@angular/core';
import { SymptomsService } from 'src/app/symptomsShared/symptoms.service';
import {NgForm} from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-asymptoms',
  templateUrl: './asymptoms.component.html',
  styleUrls: ['./asymptoms.component.scss']
})
export class AsymptomsComponent implements OnInit {

  constructor(private service : SymptomsService,private toastr: ToastrService) { }

  ngOnInit() {
    this.resetForm();
  }

  resetForm(form? : NgForm)
  {
    if(form!=null)
    form.resetForm();
    this.service.formData ={
    symptomID: null,
    symptomDescription: '',
    typeOfTB: ''
    }
  }





  onSubmit(form: NgForm)
{
	
//this.insertRecord(form);

if(form.value.symptomID == null)//reference number 999999999
this.insertRecord(form);
else
	this.updateRecord(form);

}


insertRecord(form: NgForm) {
  this.service.postSymptom(form.value).subscribe(res => {
    this.toastr.success('Inserted successfully','MEDICINE HUB');
    this.resetForm(form);
    this.service.refreshList();
  
  });
}

updateRecord(form: NgForm)
{
	this.service.putSymptom(form.value).subscribe(res =>{
		this.toastr.success('Updated successfully','MEDICINE UPDATE');
		this.resetForm(form);
    this.service.refreshList();
});


}





}
