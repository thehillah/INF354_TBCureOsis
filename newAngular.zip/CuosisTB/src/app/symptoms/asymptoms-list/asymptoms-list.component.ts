import { Component, OnInit } from '@angular/core';
import { SymptomsService } from 'src/app/symptomsShared/symptoms.service';
import { ToastrService } from 'ngx-toastr';
import { Symptoms } from 'src/app/symptomsShared/symptoms.model';

@Component({
  selector: 'app-asymptoms-list',
  templateUrl: './asymptoms-list.component.html',
  styleUrls: ['./asymptoms-list.component.scss']
})
export class AsymptomsListComponent implements OnInit {

  constructor(private service : SymptomsService,private toastr: ToastrService) { }

  ngOnInit() {
    this.service.refreshList();
  }
  populateForm(emp : Symptoms)
  {
    this.service.formData = Object.assign({},emp);
  }

  onDelete(id : number)
{
  if(confirm('Are you sure you want to delete this symptom?')){
  this.service.deleteSymptom(id).subscribe(res=>
    {this.service.refreshList();
    this.toastr.warning('Deleted Successfully','DELETE INFO');
    })
  }
}

}
