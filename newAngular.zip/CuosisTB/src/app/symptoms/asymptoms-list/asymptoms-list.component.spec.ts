import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AsymptomsListComponent } from './asymptoms-list.component';

describe('AsymptomsListComponent', () => {
  let component: AsymptomsListComponent;
  let fixture: ComponentFixture<AsymptomsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AsymptomsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AsymptomsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
