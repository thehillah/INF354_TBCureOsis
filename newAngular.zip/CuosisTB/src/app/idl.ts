export class Idl {
}
