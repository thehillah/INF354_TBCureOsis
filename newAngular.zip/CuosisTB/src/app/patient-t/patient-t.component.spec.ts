import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientTComponent } from './patient-t.component';

describe('PatientTComponent', () => {
  let component: PatientTComponent;
  let fixture: ComponentFixture<PatientTComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PatientTComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientTComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
