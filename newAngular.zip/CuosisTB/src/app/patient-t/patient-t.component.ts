import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-t',
  templateUrl: './patient-t.component.html',
  styleUrls: ['./patient-t.component.scss']
})
export class PatientTComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
