import { Injectable } from '@angular/core';
import{HttpClient } from "@angular/common/http";
import { Patient } from './patient.model';

@Injectable({
  providedIn: 'root'
})
export class PatientService {
  readonly rootUrl = "http://localhost:52362/api"

  formData : Patient;
  list : Patient[];

  constructor(private http : HttpClient) { }

  postPatient(formData : Patient)//this is then the function mentioned above...
  {
    return this.http.post(this.rootUrl+'/Patients',formData);
  }
  
  refreshList()
  {
    this.http.get(this.rootUrl+'/Patients')
    .toPromise().then(res=>this.list = res as Patient[]);
    
  }
  
  putPatient(formData:Patient)
  {
    return this.http.put(this.rootUrl+'/Patients/'+formData.patientID,formData);
  }
  
  deletePatient(id : number)
  {
    return this.http.delete(this.rootUrl+'/Patients/'+id);
  }
  
}
