import { Patient } from './patient.model';

describe('Patient', () => {
  it('should create an instance', () => {
    expect(new Patient()).toBeTruthy();
  });
});
