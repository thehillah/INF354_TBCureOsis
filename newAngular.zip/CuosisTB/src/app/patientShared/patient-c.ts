export class PatientC {
}
