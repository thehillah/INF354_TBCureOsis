export class Patient {
  patientID: number;
  patientFullName:string;
  patientGenderID:number;
  patientStatus:string;
  contactNumber: number;
  patientAddress: string;
  patientNationality: string;
}
