import { PatientC } from './patient-c';

describe('PatientC', () => {
  it('should create an instance', () => {
    expect(new PatientC()).toBeTruthy();
  });
});
