import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule, routingComponets } from './app-routing.module';
import { AppComponent } from './app.component';

import { MedicineComponent } from './Medecine/medicine/medicine.component';
import { MedecineComponent } from './medecine/medecine.component';
import { MedicineListComponent } from './Medecine/medicine-list/medicine-list.component';
import { MedicineService } from './shared/medicine.service';
import {FormsModule} from "@angular/forms";
import {HttpClientModule} from "@angular/common/http";
import {BrowserAnimationsModule} from '@Angular/platform-browser/animations';
import {ToastrModule} from 'ngx-toastr';
import { UsersComponent } from './users/users.component';
import { UsersListComponent } from './users/users-list/users-list.component';
import { HomeComponent } from './home/home.component';
import { SymptomsComponent } from './symptoms/symptoms.component';
import { AsymptomsComponent } from './symptoms/asymptoms/asymptoms.component';
import { AsymptomsListComponent } from './symptoms/asymptoms-list/asymptoms-list.component';
import { PatientTComponent } from './patient-t/patient-t.component';
import { PatientComponent } from './patientT/patient/patient.component';
import { PatientListComponent } from './patientT/patient-list/patient-list.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import {  ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    AppComponent,
    MedicineComponent,
    MedecineComponent,
    MedicineListComponent,
    UsersComponent,
    UsersListComponent,
    routingComponets,
    HomeComponent,
    SymptomsComponent,
    AsymptomsComponent,
    AsymptomsListComponent,
    PatientTComponent,
    PatientComponent,
    PatientListComponent,
    LoginComponent,
    RegisterComponent,
    DashboardComponent,
    
    
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    ReactiveFormsModule
  ],
  providers: [MedicineService],
  bootstrap: [AppComponent]
})
export class AppModule { }
