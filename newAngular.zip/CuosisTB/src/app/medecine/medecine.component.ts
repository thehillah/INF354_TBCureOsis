import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medecine',
  templateUrl: './medecine.component.html',
  styleUrls: ['./medecine.component.scss']
})
export class MedecineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
