import { Component, OnInit } from '@angular/core';
import { MedicineService } from 'src/app/shared/medicine.service';
import {NgForm} from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-medicine',
  templateUrl: './medicine.component.html',
  styleUrls: ['./medicine.component.scss']
})
export class MedicineComponent implements OnInit {

  constructor(private service : MedicineService,private toastr: ToastrService) { }

  ngOnInit() {
    this.resetForm();
  }

  resetForm(form? : NgForm)
{
	if(form!=null)
  form.resetForm();
  this.service.formData ={
  medicineID: null,
  medicineName: '',
  medicineDescription: '',
  estimatePrice: null,
  typeOfTbID: null
  }
}


onSubmit(form: NgForm)
{
	
//this.insertRecord(form);

if(form.value.medicineID == null)//reference number 999999999
this.insertRecord(form);
else
	this.updateRecord(form);

}


insertRecord(form: NgForm) {
  this.service.postMedicine(form.value).subscribe(res => {
    this.toastr.success('Inserted successfully','MEDICINE HUB');
    this.resetForm(form);
    this.service.refreshList();
  
  });
}

updateRecord(form: NgForm)
{
	this.service.putMedicine(form.value).subscribe(res =>{
		this.toastr.success('Updated successfully','MEDICINE UPDATE');
		this.resetForm(form);
    this.service.refreshList();
});


}

}

