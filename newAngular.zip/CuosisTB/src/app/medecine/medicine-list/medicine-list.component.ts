import { Component, OnInit } from '@angular/core';
import { MedicineService } from 'src/app/shared/medicine.service';
import { Medicinec } from 'src/app/shared/medicinec.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-medicine-list',
  templateUrl: './medicine-list.component.html',
  styleUrls: ['./medicine-list.component.scss']
})
export class MedicineListComponent implements OnInit {

  constructor(private service : MedicineService,private toastr: ToastrService) { }

  ngOnInit() {
    this.service.refreshList();
  }
  populateForm(emp : Medicinec)
{
  this.service.formData = Object.assign({},emp);
}

onDelete(id : number)
{
  if(confirm('Are you sure you want to delete this Medicine?')){
  this.service.deleteMedicine(id).subscribe(res=>
    {this.service.refreshList();
    this.toastr.warning('Deleted Successfully','DELETE INFO');
    })
  }
}



}
