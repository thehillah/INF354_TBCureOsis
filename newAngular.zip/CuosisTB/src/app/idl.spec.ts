import { Idl } from './idl';

describe('Idl', () => {
  it('should create an instance', () => {
    expect(new Idl()).toBeTruthy();
  });
});
