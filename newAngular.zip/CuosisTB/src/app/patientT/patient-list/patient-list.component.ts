import { Component, OnInit } from '@angular/core';
import { PatientService } from 'src/app/patientShared/patient.service';
import { ToastrService } from 'ngx-toastr';
import { Patient } from 'src/app/patientShared/patient.model';

@Component({
  selector: 'app-patient-list',
  templateUrl: './patient-list.component.html',
  styleUrls: ['./patient-list.component.scss']
})
export class PatientListComponent implements OnInit {

  constructor(private service : PatientService,private toastr: ToastrService) { }

  ngOnInit() {
    this.service.refreshList();
  }

  populateForm(emp : Patient)
{
  this.service.formData = Object.assign({},emp);
}
onDelete(id : number)
{
  if(confirm('Are you sure you want to delete this Patient?')){
  this.service.deletePatient(id).subscribe(res=>
    {this.service.refreshList();
    this.toastr.warning('Deleted Successfully','DELETE INFO');
    })
  }
}

}
