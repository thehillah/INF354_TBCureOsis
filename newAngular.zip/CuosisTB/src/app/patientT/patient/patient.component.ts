import { Component, OnInit } from '@angular/core';
import { PatientService } from 'src/app/patientShared/patient.service';
import { ToastrService } from 'ngx-toastr';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.scss']
})
export class PatientComponent implements OnInit {

  constructor(private service : PatientService,private toastr: ToastrService) { }
  

  ngOnInit() {
    this.resetForm();
  }

  resetForm(form? : NgForm)
  {
    if(form!=null)
    form.resetForm();
    this.service.formData ={
      patientID: null,
      patientFullName:'',
      patientGenderID:null,
      patientStatus:'',
      contactNumber: null,
      patientAddress: '',
      patientNationality: ''
    }

     
  }

 

  onSubmit(form: NgForm)
{
	
//this.insertRecord(form);

if(form.value.patientID == null)//reference number 999999999
this.insertRecord(form);
else
	this.updateRecord(form);

}




insertRecord(form: NgForm) {
  this.service.postPatient(form.value).subscribe(res => {
    this.toastr.success('Inserted successfully','MEDICINE HUB');
    this.resetForm(form);
    this.service.refreshList();
  
  });
}

updateRecord(form: NgForm)
{
	this.service.putPatient(form.value).subscribe(res =>{
		this.toastr.success('Updated successfully','MEDICINE HUD');
		this.resetForm(form);
    this.service.refreshList();
});


}


}
