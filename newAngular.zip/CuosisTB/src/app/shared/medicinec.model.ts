export class Medicinec {
    medicineID: number;
  medicineName:string;
  medicineDescription:string;
  estimatePrice: number;
  typeOfTbID: number;
}
