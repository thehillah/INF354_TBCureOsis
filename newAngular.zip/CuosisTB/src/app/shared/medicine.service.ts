import { Injectable } from '@angular/core';
import{Medicinec} from './medicinec.model';
import{HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class MedicineService {
  readonly rootUrl = "http://localhost:52362/api"

  formData : Medicinec;
  list : Medicinec[];
  constructor(private http : HttpClient) { }

  postMedicine(formData : Medicinec)//this is then the function mentioned above...
{
	return this.http.post(this.rootUrl+'/Medicines',formData);
}

refreshList()
{
	this.http.get(this.rootUrl+'/Medicines')
	.toPromise().then(res=>this.list = res as Medicinec[]);
	
}

putMedicine(formData:Medicinec)
{
	return this.http.put(this.rootUrl+'/Medicines/'+formData.medicineID,formData);
}

deleteMedicine(id : number)
{
  return this.http.delete(this.rootUrl+'/Medicines/'+id);
}


}
