import { Medicinec } from './medicinec.model';

describe('Medicinec', () => {
  it('should create an instance', () => {
    expect(new Medicinec()).toBeTruthy();
  });
});
