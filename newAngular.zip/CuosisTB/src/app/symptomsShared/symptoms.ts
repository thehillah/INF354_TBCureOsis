export class Symptoms {
  
}
