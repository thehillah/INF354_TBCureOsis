export class Symptoms {
    
}
