export class Symptoms {
  symptomID: number;
  symptomDescription:string;
  typeOfTB:string;
}
