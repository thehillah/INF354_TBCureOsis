import { Symptoms } from './symptoms';

describe('Symptoms', () => {
  it('should create an instance', () => {
    expect(new Symptoms()).toBeTruthy();
  });
});
