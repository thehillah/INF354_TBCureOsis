import { Injectable } from '@angular/core';
import {Symptoms} from './symptoms.model'
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SymptomsService {
  readonly rootUrl = "http://localhost:52362/api"

  formData : Symptoms;
  list : Symptoms[];
  constructor(private http : HttpClient) { }

  postSymptom(formData : Symptoms)//this is then the function mentioned above...
{
	return this.http.post(this.rootUrl+'/Symptoms',formData);
}

refreshList()
{
	this.http.get(this.rootUrl+'/Symptoms')
	.toPromise().then(res=>this.list = res as Symptoms[]);
	
}

putSymptom(formData:Symptoms)
{
	return this.http.put(this.rootUrl+'/Symptoms/'+formData.symptomID,formData);
}

deleteSymptom(id : number)
{
  return this.http.delete(this.rootUrl+'/Symptoms/'+id);
}



}
