import { Symptoms } from './symptoms.model';

describe('Symptoms', () => {
  it('should create an instance', () => {
    expect(new Symptoms()).toBeTruthy();
  });
});
