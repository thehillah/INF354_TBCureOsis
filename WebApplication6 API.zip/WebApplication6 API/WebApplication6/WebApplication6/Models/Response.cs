﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication6.Models
{
    public class Response
    {
        public string Status { set; get; }
        public string Message { set; get; }
    }
}